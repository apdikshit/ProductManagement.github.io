﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ProductManagement.Models;
using Microsoft.AspNetCore.Hosting;
using System.IO;

namespace ProductManagement.Controllers
{
    public class UserController : Controller
    {
        private AppDbContext Db;

        public IHostingEnvironment Environment { get; }

        public UserController(AppDbContext context,IHostingEnvironment environment)
        {
            Db = context;
            Environment = environment;
        }
        public IActionResult Index( User user)
        {
            var st = Db.users.ToList();
            return View(st);
        }
        [HttpPost]
        public IActionResult Login(User U,string email,string password)
        {
            /*var mail = Db.users.Where(e => e.Email == email && e.Password == password);*/
            if (U.Email==email && U.Password==password)
            {

                return RedirectToAction("DashBoard");
            }
            else
            {
                ViewBag.msg = "Cannot verified your Email try After some time";
                return View();
            }
        }
       /* public IActionResult SignUp()
        {
            return View();
        }
        [HttpPost]
        public IActionResult SignUp(User user)
        {
            var files = Request.Form.Files;
            string dbpath = string.Empty;
            if (files.Count>0) 
            {
                string path = Environment.WebRootPath;
                string fullpath = Path.Combine(path,"images",files[0].FileName);
                dbpath = "images/" + files[0].FileName;
                FileStream stream = new FileStream(fullpath, FileMode.Create);
                files[0].CopyTo(stream);
            }
            user.Image = dbpath;
            Db.users.Add(user);
            Db.SaveChanges();
            return RedirectToAction("Check");
        }*/
    
    }
}
